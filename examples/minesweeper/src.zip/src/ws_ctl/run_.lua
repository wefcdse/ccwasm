Args = {...}
Id = Args[1]
Port = Args[2]
if Id == nil then
    Id = os.getComputerLabel()
end
if Id == nil then
    Id = tostring(os.getComputerID())
end

if Port == nil then
    Port = "13000"
end

local ws = assert(http.websocket(string.format("ws://127.0.0.1:%d/ws", Port)))
ws.send(string.format("id %s",Id))
print(Id, Port)

Split = require("string_split").split;
ProcRedstone = require("proc_redstone")
ProcGPS = require("proc_gps")
ProcEvent = require("proc_event")
ProcPeri = require("proc_peri")
ProcMonitor = require("proc_monitor")

while true do
    -- os.sleep(0)
    while true do
        local incoming, b = ws.receive()
        if incoming == nil then
            break
        end
        -- print(incoming)
        local cmd = Split(incoming, " ")
        assert(cmd)
        if cmd[1] =="g_rs" then
            ProcRedstone.GetRedstone(ws, cmd[2])
        end

        if cmd[1] =="s_rs" then
            ProcRedstone.SetRedstone(cmd[2], cmd[3])
        end

        if cmd[1] == "gps_loc" then
            ProcGPS.Locate(ws)
        end

        if cmd[1] == "evt" then
            ProcEvent.ProcEvent(ws)
        end

        if cmd[1] == "g_peri" then
            ProcPeri.ProcPeri(ws, cmd[2])
        end

        if cmd[1] == "m_w_at_c" then
            -- m_w_at_c side x y c1 c2
            -- text
            local text, b = ws.receive()
            if text == nil then
                break
            end
            -- print("here")
            ProcMonitor.WriteAtWithBGColor(cmd[2], tonumber(cmd[3]), tonumber(cmd[4]), text, tonumber(cmd[5]), tonumber(cmd[6]))
        end

        if cmd[1] == "m_w_at_c_sig" then
            -- m_w_at_c_sig side x y c1 c2 is_space char
            -- text
            local text = cmd[8]
            if cmd[7] == "true" then
                text = " "
            end
            -- print("here")
            ProcMonitor.WriteAtWithBGColor(cmd[2], tonumber(cmd[3]), tonumber(cmd[4]), text, tonumber(cmd[5]), tonumber(cmd[6]))
        end


        

        if cmd[1] == "m_g_sz" then
            ProcMonitor.GetSize(ws, cmd[2])
        end

        if cmd[1] == "msm" then
            -- 1   2     3     4    5   6  7  8        9
            --                 base +1  +2 +3 +4       +5
            -- msm count side [x    y   c1 c2 is_space char]
            -- text
            local count = cmd[2]
            local side = cmd[3]

            local p = peripheral.wrap(side);
            if p == nil then
                print(side)
                break
            end
        
            local x_max, y_max = p.getSize()

            for i = 1, count, 1 do
                local base = i * 6 -2

                local text = cmd[base + 5]
                if cmd[base + 4] == "true" then
                    text = " "
                end
                -- print("here")
                ProcMonitor.WriteAtWithBGColorWithP(p, x_max, y_max, tonumber(cmd[base]), tonumber(cmd[base + 1]), text, tonumber(cmd[base + 2]), tonumber(cmd[base + 3]))

            end
                

        end

        -- os.sleep(0)

        break
    end

end
