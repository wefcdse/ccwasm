use std::{
    borrow::Borrow,
    cell::{RefCell, UnsafeCell},
    ops::{Deref, DerefMut},
    time::Instant,
};

use cc_wasm_api::{debug::show_str, eval::yield_lua, prelude::*};
use functions::{init_monitor, write_pix};
use local_monitor::LocalMonitor;
use rand::random;
use simple_cell::{SimpleCell, Syncer};
use utils::{AsIfPixel, ColorId};

// mod ms;
mod functions;
mod local_monitor;
mod simple_cell;
mod utils;
mod vec2d;

export_funcs!(init);

fn init() {
    if false {
        // TickSyncer::spawn_handle_coroutine();
        async {
            let mut ts = TickSyncer::new();
            loop {
                // ts.sync().await;
                yield_now().await;
            }
        }
        .spawn();
        async {
            let mut ts = TickSyncer::new();

            loop {
                // ts.sync().await;
                poll_evt().await;
            }
        }
        .spawn();

        return;
    }

    // TickSyncer::spawn_handle_coroutine();
    async {
        loop {
            // poll_evt().await;
            yield_now().await;
            unsafe { TickSyncer::handle_sync() }.await;
        }
    }
    .spawn();
    async {
        let mut ts = TickSyncer::new();
        let mut now = Instant::now();
        loop {
            poll_evt().await;
            ts.sync().await;
            // exec(&format!("print(\"{}\")", now.elapsed().as_micros()))
            //     .await

            //     .unwrap();
            now = Instant::now();
        }
    }
    .spawn();

    async {
        let mut ts = TickSyncer::new();

        loop {
            for _ in 0..100 {
                yield_now().await;
            }
            ts.sync().await;
        }
    }
    .spawn();
}

async fn poll_evt() {
    let script: &str = r#"
        os.queueEvent("aaaa")
        local event_data = {os.pullEvent()}
        if event_data[1] == "monitor_touch" then
            return unpack(event_data)
        end
        if event_data[1] == "aaaa" then
            return
        end
        print(event_data[1])
        "#;

    // let script: &str = r#"
    //     return poll()
    //     "#;

    // let script = "return os.pullEvent(\"monitor_touch\")";
    for _ in 0..20 {
        if let Some((_, _, x, y)) = eval::<Option<(String, String, Number, Number)>>(script)
            .await
            .unwrap()
        {
        } else {
            // return;
        }
    }
}
