
function ProcEvent(ws, event_type)
    local timer = os.startTimer(0)
    local event_data = {os.pullEvent()}
    -- print(2)
    -- print(event_data[1])


    if event_data[1] == "timer" then
        ws.send("none")
        return;
    end

    local tosend = event_data[1]
    for key, value in pairs(event_data) do
        if not (key == 1) then
            tosend = string.format("%s %s", tosend, value);
        end
    end
    -- print(tosend)

    ws.send(tosend)

end


return { ProcEvent = ProcEvent }