use cc_wasm_api::debug::show_str;
use cc_wasm_api::prelude::*;

use crate::utils::AsIfPixel;

pub async fn write_pix(x: i32, y: i32, pix: AsIfPixel) {
    // return;
    let script = format!(
        "global.monitor.setCursorPos({x}, {y})
    global.monitor.setBackgroundColour({bc})
    global.monitor.setTextColour({tc})
    global.monitor.write(\"{txt}\")",
        x = x + 1,
        y = y + 1,
        bc = pix.background_color.to_number(),
        tc = pix.text_color.to_number(),
        txt = pix.text().to_string()
    );
    // show_str(&script);
    exec(&script).await.unwrap();
}

pub async fn init_monitor() {
    exec("global.monitor = peripheral.wrap(\"top\")")
        .await
        .unwrap();
}
