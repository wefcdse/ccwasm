use std::{
    borrow::Borrow,
    cell::{RefCell, UnsafeCell},
    ops::{Deref, DerefMut},
};

use cc_wasm_api::{debug::show_str, eval::yield_lua, prelude::*};
use functions::{init_monitor, write_pix};
use local_monitor::LocalMonitor;
use rand::random;
use simple_cell::{SimpleCell, Syncer};
use utils::{AsIfPixel, ColorId};

// mod ms;
mod functions;
mod local_monitor;
mod simple_cell;
mod utils;
mod vec2d;

export_funcs!(init);
static CLICKED: SyncNonSync<UnsyncChannel<(i32, i32)>> = SyncNonSync(UnsyncChannel::new(0));
static MONITOR: SyncNonSync<SimpleCell<LocalMonitor>> = SyncNonSync(SimpleCell::new());
static B: SyncNonSync<Syncer> = SyncNonSync(Syncer::new());

fn init() {
    MONITOR.init(LocalMonitor::new(
        0,
        0,
        AsIfPixel::new(' ', ColorId::Blue, ColorId::Orange).unwrap(),
    ));

    async {
        loop {
            // yield_lua().await;
            poll_evt().await;
            // B.notify();
            // for _ in 0..100 {
            //     yield_now().await;
            // }
            unsafe { TickSyncer::handle_sync() }.await;
        }
    }
    .spawn();
    // return;
    async {
        let mut ts = TickSyncer::new();
        loop {
            while let Some((x, y)) = CLICKED.try_get() {
                // exec(&format!("print(\"{}, {}\")", x, y)).await.unwrap();

                let p = AsIfPixel::new(' ', ColorId::Black, ColorId::Black).unwrap();
                // functions::write_pix(x - 1, y - 1, p).await;
                MONITOR.get().write(x as usize, y as usize, p);
                // MONITOR.get().sync().await;
            }
            B.notify();
            ts.sync().await;
        }
    }
    .spawn();
    async {
        let mut ts = TickSyncer::new();
        init_monitor().await;
        let size: (Number, Number) = eval("return monitor.getSize()").await.unwrap();
        MONITOR.get().resize(
            size.0.to_i32() as usize,
            size.1.to_i32() as usize,
            AsIfPixel::new(' ', ColorId::Blue, ColorId::Orange).unwrap(),
        );
        MONITOR.get().sync_all().await;
        loop {
            B.wait(1).await;
            MONITOR.get().sync().await;
            ts.sync().await;
        }
    }
    .spawn();
    async {
        let mut ts = TickSyncer::new();
        loop {
            for i in 0..10 {
                let p = AsIfPixel::new(
                    ' ',
                    ColorId::from_number_overflow(random()),
                    ColorId::from_number_overflow(random()),
                )
                .unwrap();
                MONITOR.get().write(1, MONITOR.get().y() - i, p);
            }
            B.notify();
            ts.sync().await;
        }
    }
    .spawn();
}
fn old1() {
    async {
        let mut ts = TickSyncer::new();
        init_monitor().await;
        let size: (Number, Number) = eval("return monitor.getSize()").await.unwrap();
        exec(&format!("print(\"{:?}\")", size)).await.unwrap();
        loop {
            let (_, _, x, y): (String, String, Number, Number) =
                eval("return os.pullEvent(\"monitor_touch\")")
                    .await
                    .unwrap();
            exec(&format!("print(\"{}, {}\")", x, y)).await.unwrap();
            for x in 1..=size.0.to_i32() {
                for y in 1..=size.1.to_i32() {
                    write_pix(
                        x,
                        y,
                        AsIfPixel::new('a', ColorId::Blue, ColorId::Orange).unwrap(),
                    )
                    .await;
                }
            }
            ts.sync().await;
        }
    }
    .spawn();
}
async fn poll_evt() {
    let script: &str = r#"
        os.queueEvent("aaaa")
        local event_data = {os.pullEvent()}
        if event_data[1] == "monitor_touch" then
            return unpack(event_data)
        end
        if event_data[1] == "aaaa" then
            return
        end
        "#;
    // let script = "return os.pullEvent(\"monitor_touch\")";
    for _ in 0..20 {
        if let Some((_, _, x, y)) = eval::<Option<(String, String, Number, Number)>>(script)
            .await
            .unwrap()
        {
            // exec(&format!("print(\"{}, {}\")", x, y)).await.unwrap();

            // let p = AsIfPixel::new(' ', ColorId::Black, ColorId::Black).unwrap();
            // functions::write_pix(x.to_i32() - 1, y.to_i32() - 1, p).await;
            CLICKED.insert((x.to_i32(), y.to_i32())).await;
            // let p = AsIfPixel::new(' ', ColorId::Black, ColorId::Black).unwrap();
            // MONITOR
            //     .get()
            //     .write(x.to_i32() as usize, y.to_i32() as usize, p);
        } else {
            // return;
        }
    }
}
